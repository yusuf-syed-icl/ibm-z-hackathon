import pandas as pd
import numpy as np
import random as rdm
from random import random
from scipy.stats import norm
import matplotlib.pyplot as plt

cost_limit = 2.0            # Set cost allowance
N = 20                      # Set node tree size
duration_scaling = 10.0     # Set linear scaling for repair duration against criticality

sampling_step = 1           # Optimiser timestep
sigma = 1                   # Standard deviation of dissipation model
total_cost = 0.0            # Initialise cost limit
time_step = 1               # Initialise time step counter

# Integrated inputs from ML analysis inputted here (random generation shown for demo)

values = [round(i * 0.1, 1) for i in range(1, 11)]
base_usage = [rdm.choice(values) for _ in range(N)]         # Base usage intensity rating for each node
base_criticality = [rdm.choice(values) for _ in range(N)]   # Base criticality rating for each node

# Generate dataframe to enapsulate node data

data = {
    'node_index': [i for i in range(N)],
    'criticality': base_criticality,
    'usage_intensity': base_usage,
    'duration': [duration_scaling*i for i in base_criticality],
    'x': [random() for _ in range(N)],
    'y': [random() for _ in range(N)],
    'status': [False for _ in range(N)],
    'radius': [0 for _ in range(N)]
}

df = pd.DataFrame(data)

with open('logger.txt', 'w') as logger:

    # Whilst unrepaired node locations exist, solve optimiser

    while (df['status'] == False).any():

        # While within cost allowance, continue optimising

        while total_cost < cost_limit:
            
            # If problem complete, exit

            if not (df['status'] == False).any():
                break

            # Calculate the cost function (proportional to criticality and inversely proportional to usage intensity)

            df['cost_function'] = df['criticality'] / df['usage_intensity']

            # Filter nodes under repair

            greedy_select = df[df['status'] == True]
            
            # Define solution space as remaining nodes

            solution_space = df[df['status'] == False]

            # Sort solution space based on cost function

            solution_space = solution_space.sort_values(by='cost_function', ascending=False)

            # Implement Greedy algorithm by selecting locally optimum choice and evaluating impact on remaining nodes

            top_node_idx = solution_space.index[0]
            solution_space.at[top_node_idx, 'status'] = True

            # Calculate radius for all other nodes with respect to the chosen top node

            solution_space['radius'] = np.sqrt((solution_space['x'] - solution_space.at[top_node_idx, 'x'])**2 + 
                                            (solution_space['y'] - solution_space.at[top_node_idx, 'y'])**2)
            
            # Sort solution based on radius for dissipation model integral bounds

            sorted_space = solution_space.sort_values(by='radius', ascending=True)

            # Update total cost

            total_cost += sorted_space.iloc[0]['cost_function']

            # Concatenate Greedy algorithm selections with remaining nodes

            df = pd.concat([greedy_select, sorted_space], ignore_index=True)
            df.reset_index(drop=True, inplace=True)

            # Compute effect of Greedy selection of remaining nodes based on proximity using dissipation model

            for i in range(len(greedy_select) + 1, len(df) - 1):
                delta_u = 2.0 * (norm.cdf(df.loc[i, 'radius'], loc=0, scale=sigma) - 
                                norm.cdf(df.loc[i - 1, 'radius'], loc=0, scale=sigma))
                df.loc[i, 'usage_intensity'] += delta_u

            # Log results

            print(df)
            print(total_cost)
            print(time_step)

        remains = df[df['status'] == False]
        logger.write(str(remains['criticality'].sum()) + ", " + str(remains['usage_intensity'].sum()) + ", " + str(len(remains)) + "\n")

        time_step += 1
        
        # Evaluate repair duration remaining and correct total cost

        df.loc[df['status'] == True, 'duration'] -= sampling_step
        total_cost = df.loc[(df['status'] == True) & (df['duration'] > 0), 'cost_function'].sum()
    
    logger.close()
    

